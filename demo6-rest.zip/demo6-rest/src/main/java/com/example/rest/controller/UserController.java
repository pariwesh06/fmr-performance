package com.example.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.UserService;
import com.example.demo.entity.User;

@RestController
public class UserController {
	List<User> users ;
	@Autowired
	UserService userService;
	@RequestMapping(value="/user", method=RequestMethod.GET)
	public List<User> getUsers() {
		users =  userService.search(null);
		return users;
	}
	
	@RequestMapping(value="/user/{id}", method=RequestMethod.GET)
	public List<User> getUser(@PathVariable("id") Integer id) {
		List<User> users = setCriteria(id, null);
		return users;
	}
	
	@RequestMapping(value="/user/{id}/{fname}", method=RequestMethod.GET)
	public List<User> getUserWithFnameAndID(@PathVariable("id") Integer id, 
			@PathVariable("fname") String fname) {
		return setCriteria(id, fname);
	}

	private List<User> setCriteria(Integer id, String fname) {
		User user = new User();
		user.setId(id);
		if(fname!= null){
			user.setFname(fname);
		}
		return userService.search(user);
	}
	//save
	@RequestMapping(value="/user", method=RequestMethod.POST)
	public boolean getUserWithFnameAndID(@RequestBody User user) throws Exception {
		return userService.save(user);
	}
}
