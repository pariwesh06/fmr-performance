package com.example;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.User;
@Component
public class UserService {
	@Autowired
	IUserDAL userDAL ;
	int count=0;
	@Transactional(rollbackFor=Exception.class)
	public boolean save(User user) throws Exception {
		userDAL.save1(user);
//		throw new Exception();
		return true;
	}
	
	public List<User> search(User user) {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<User> users =userDAL.search(user);
		System.out.println("fetched users="+users);
		return users;
	}
}
