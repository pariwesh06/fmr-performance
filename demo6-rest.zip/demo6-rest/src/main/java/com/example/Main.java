package com.example;

import javax.sql.DataSource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@SpringBootApplication
@ImportResource("context.xml")
public class Main {
	public static void main(String[] args) {
		SpringApplication.run(Main.class, args);
	}

	@Bean
	public DataSource dataSource() {
		System.out.println("datasoruce init");
		DriverManagerDataSource driverManager = new DriverManagerDataSource("jdbc:mysql://localhost:3306/fidelity",
				"root", "");
		driverManager.setDriverClassName("com.mysql.jdbc.Driver");
		return driverManager;
	}
}
