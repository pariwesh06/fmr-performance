package com.example.demo.entity;

public class User { //value object
	private String fname;
	private Integer id;
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}
	@Override
		public String toString() {
			return this.fname;
		}
}
