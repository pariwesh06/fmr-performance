package com.example;

import java.util.List;

import com.example.demo.entity.User;

public interface IUserDAL {
	void save1(User user);

	List<User> search(User criteria);
}
