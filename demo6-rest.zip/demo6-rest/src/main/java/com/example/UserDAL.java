package com.example;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.example.demo.entity.User;

@Component
public class UserDAL implements IUserDAL {
	JdbcTemplate template;

	public UserDAL(DataSource dataSource) {
		template = new JdbcTemplate(dataSource);
	}

	public void save1(User user) {
		System.out.println("in UserDAL...");
		template.execute("INSERT INTO USer(fname,age) values( 'Ajay', 40)");
	}

	@Override
	public List<User> search(User criteria) {
		StringBuilder query = new StringBuilder("SELECT * from user ");
		if (criteria != null) {
			query.append(" WHERE ");
			if (criteria.getFname() != null) {
				query = query.append(" fname='").append(criteria.getFname()).append("' AND ");
			}
			if (criteria.getId() != null) {
				query = query.append(" id=").append(criteria.getId());
			}
		}
		List<User> users = template.query(query.toString(), new RowMapper() {
			public User mapRow(ResultSet rs, int row) throws SQLException {
				String fname = rs.getString("fname");
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setFname(fname);
				// users.add(user);
				return user;
			}
		});
		return users;
	}
}